/*
** $Id$
**
**    Copyright (C) 2006 Sander Huijsen 
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    any later version.
**
**    This program is distributed in the hope that it will be useful,
**    but WITHOUT ANY WARRANTY; without even the implied warranty of
**    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**    GNU General Public License for more details.
**
**    You should have received a copy of the GNU General Public License
**    along with this program; if not, write to the Free Software
**    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef GENERAL_H
#define GENERAL_H

#include <system.h>
#include "types.h"

#define forever		while(1)

// Some delays
#define C_2MS	(225)
#define C_3MS	(209)
#define C_4MS	(194)
#define C_5MS	(178)
#define C_6MS	(162)
#define C_7MS	(147)

// Some common baudrates - based on 16.000MHz clock
#define BAUD19K2	(51)
#define BAUD33K6	(29)
#define BAUD38K4	(25)
#define BAUD57K6	(16)
#define BAUD115K2	 (8)

// Turn on global interrupts
inline void ei( void ) { set_bit(intcon,GIE); }

// Turn off global interrupts
inline void di( void ) { clear_bit(intcon,GIE); }

#define WDT_DELAY(X)	( (wdtcon&0b11100000) | (X) )

// WDT timeouts
#define WDT_1MS			WDT_DELAY(0b00001)
#define WDT_2MS			WDT_DELAY(0b00011)
#define WDT_4MS			WDT_DELAY(0b00101)
#define WDT_8MS			WDT_DELAY(0b00111)
#define WDT_16MS		WDT_DELAY(0b01001)
#define WDT_33MS		WDT_DELAY(0b01011)
#define WDT_66MS		WDT_DELAY(0b01101)
#define WDT_131MS		WDT_DELAY(0b01111)
#define WDT_262MS		WDT_DELAY(0b10001)
#define WDT_524MS		WDT_DELAY(0b10011)
#define WDT_1048MS		WDT_DELAY(0b10101)
#define WDT_2097MS		WDT_DELAY(0b10111)

// Restart Causes
#define WDT_FROM_SLEEP	 	 0
#define WDT_TIMEOUT       	 8
#define MCLR_FROM_SLEEP  	16
#define NORMAL_POWER_UP  	24

// Determine cause of restart
inline u8 restart_cause( void )
{
	if( !test_bit(pcon,NOT_POR) )
		return NORMAL_POWER_UP;

	if( test_bit(status,NOT_TO) )
		return MCLR_FROM_SLEEP;

	if( !test_bit(status,NOT_PD) )
		return WDT_TIMEOUT;

	return WDT_FROM_SLEEP;
}

#endif /* GENERAL_H */
