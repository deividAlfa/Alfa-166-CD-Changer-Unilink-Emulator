/*
** $Id$
**
**    Copyright (C) 2006 Sander Huijsen 
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    any later version.
**
**    This program is distributed in the hope that it will be useful,
**    but WITHOUT ANY WARRANTY; without even the implied warranty of
**    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**    GNU General Public License for more details.
**
**    You should have received a copy of the GNU General Public License
**    along with this program; if not, write to the Free Software
**    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef IPOD_H
#define IPOD_H

#include "version.h"
#include "general.h"
#include "types.h"

#define IPO_MODE_SIMPLE		0x02
#define IPO_MODE_AIR		0x04

// Available commands - somewhat maps onto real commands
enum e_ipo_command
{
	IPO_NONE      	=  0,
	IPO_PLAY	   	=  1,
	IPO_STOP		=  2,
	IPO_NEXT		=  3,
	IPO_PREV		=  4,
	IPO_FFWD		=  5,
	IPO_RWD			=  6,
	IPO_KEYOFF		=  7,
	IPO_MODE		= 10,
	IPO_PLAYLIST	= 11,
	IPO_EXECUTE		= 12,
	IPO_STATUS		= 13,
	IPO_SHUFFLE     = 14,
	IPO_PLAY_MODE2  = 15,
	IPO_PAUSE_MODE2 = 16
};

// Some ipod flags
enum e_ipo_flags 
{
	f_ipo_tx = 0,
	f_ipo_rx,
	f_ipo_hold,
	f_ipo_playlist,
	f_ipo_execute,
	f_ipo_timeout,
	f_ipo_rx_compl,
	f_ipo_status
};

// Some exported variables
#define IPO_ST_STOP			0
#define IPO_ST_PLAYING		1
#define IPO_ST_PAUSED		2

extern u8 ipo_flags;
extern u8 ipo_status;

#ifdef ENABLE_IPOD

/*
 * Timer clock = 4 000 000 Hz
 * Prescaler: 8 (500 000 Hz == 2 us per tick)
 * 10 ms = 5000 ticks
 * 65536 - 5000 = 60536 = 0xec78
 */
#define TIMER1_HI	0xec
#define TIMER1_LO	0x78

#define RELOAD_TIMER1	{ \
	tmr1l = 0x0; \
	tmr1h = TIMER1_HI; \
	tmr1l = TIMER1_LO; \
}	

#define IPO_MAX_RX_SIZE		32		/* MUST be power of 2 */

extern u8 ipo_rxsize;
extern u8 ipo_rxindex;
extern u8 ipo_rxdata[IPO_MAX_RX_SIZE];

#define IPO_MAX_TX_SIZE		12

extern u8 ipo_txsize;
extern u8 ipo_txindex;
extern u8 ipo_txdata[IPO_MAX_TX_SIZE];

// Function prototypes
void ipo_init( void );
void ipo_add_queue( const u8 cmd, const u8 parm );
void ipo_process_queue( void );
void ipo_parse( void );

/*
 * Inline function for TX interrupt handling
 */
inline void ipo_tx_interrupt( void )
{
	// USART TX interrupt
	if( test_bit(pie1,TXIE) && test_bit(pir1,TXIF) )
	{
		// Are we actually sending a command?
		if( test_bit(ipo_flags,f_ipo_tx) )
		{
			// Finished?
			if( ipo_txindex < ipo_txsize )
			{
				// No: send next character
				txreg = ipo_txdata[ipo_txindex];
				++ipo_txindex;
			}
			else
			{
				// Yes: turn off interrupts because TXIF 
				// cannot be cleared in software!
				clear_bit( pie1,TXIE );
				clear_bit( ipo_flags,f_ipo_tx );
				if( test_bit(ipo_flags,f_ipo_playlist) )
				{
					clear_bit( ipo_flags,f_ipo_playlist );
					set_bit( ipo_flags,f_ipo_execute );
				}
			}
		}
	}
}

/*
 * Inline function for RX interrupt handling
 */
inline void ipo_rx_interrupt( void )
{
	// USART RX interrupt
	if( test_bit(pie1,RCIE) && test_bit(pir1,RCIF) )
	{
		// Copy received character
		ipo_rxdata[ipo_rxindex] = rcreg;

		// Very basic synchronisation
		if(   ipo_rxindex == 0
		   && ipo_rxdata[0] != 0xff )
		{
			return;
		}

		// Determine command length (variable!)
		if( ipo_rxindex >= 2 )
			ipo_rxsize = ipo_rxdata[2] + 4;

		// Calculate next index value
		ipo_rxindex = (ipo_rxindex+1) & (IPO_MAX_RX_SIZE-1);

		// Check whether we've received a complete ipod command
		if( ipo_rxindex >= ipo_rxsize )
		{
			ipo_rxindex = 0;
			ipo_rxsize = IPO_MAX_RX_SIZE-1;
			set_bit( ipo_flags,f_ipo_rx_compl );
		}

		// Clear interrupt flag
		clear_bit( pir1,RCIF );
	}
}

/*
 * Inline function for timer1 interrupt handling
 */
inline void ipo_timer1_interrupt( void )
{
	// Timer1 interrupt
	if( test_bit(pie1,TMR1IE) && test_bit(pir1,TMR1IF) )
	{
		RELOAD_TIMER1;

		set_bit( ipo_flags,f_ipo_timeout );
		clear_bit( pir1,TMR1IF );
	}
}

#else

inline void ipo_init( void ) { };
inline void ipo_add_queue( const u8 cmd, const u8 parm ) { };
inline void ipo_process_queue( void ) { };
inline void ipo_parse( void ) { };
inline void ipo_rx_interrupt( void ) { };
inline void ipo_tx_interrupt( void ) { };
inline void ipo_timer1_interrupt( void ) { };

#endif /* ENABLE_IPOD */

#endif /* IPOD_H */
