/*
** $Id$
**
**    Copyright (C) 2006 Sander Huijsen 
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    any later version.
**
**    This program is distributed in the hope that it will be useful,
**    but WITHOUT ANY WARRANTY; without even the implied warranty of
**    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**    GNU General Public License for more details.
**
**    You should have received a copy of the GNU General Public License
**    along with this program; if not, write to the Free Software
**    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include <system.h>
#include "general.h"
#include "ipod.h"
#include "led.h"

volatile u8 ipo_status = 0;
volatile u8 ipo_flags = 0;

#ifdef ENABLE_IPOD

#define QUEUE_DEPTH		8	/* MUST be power of 2 */

volatile static u8 ipo_queue_rd = 0;
volatile static u8 ipo_queue_wr = 0;

typedef struct queue_item_s {
	u8 cmd;
	u8 parm;
} s_queue_item;

volatile static s_queue_item ipo_queue[QUEUE_DEPTH];

// ipod commands (0x00 0x29)
enum c_ipo_commands
{
	c_play      = 1,
	c_stop      = 2,
	c_next      = 3,
	c_prev      = 4,
	c_ffwd      = 5,
	c_rwd       = 6,
	c_keyoff	= 7
};

// Positions in ipod command buffer
enum c_pos
{
	c_hdr1 		= 0,
	c_hdr2 		= 1,
	c_len  		= 2,
	c_mode 		= 3,
	c_cmd1 		= 4,
	c_cmd2 		= 5
};

#define PLAYLIST_MAINLIB	(1)

// The ipod commands
#define IPO_INIT(MMODE)		{0x03, 0x00, 0x01, MMODE, 0xFC-MMODE}
#define IPO_LIST(MLIST)		{0x08, 0x04, 0x00, 0x17, 0x01, 0x00, 0x00, 0x00, MLIST, 0xDC-MLIST}
#define IPO_STAT			{0x03, 0x04, 0x00, 0x1C, 0xDD}
#define IPO_EXEC			{0x07, 0x04, 0x00, 0x28, 0xff, 0xff, 0xff, 0xff, 0xD1}
#define IPO_COMMAND(MCMD)	{0x04, 0x04, 0x00, 0x29, MCMD, 0xCF-MCMD}
#define IPO_SHUF(MSH)		{0x04, 0x04, 0x00, 0x2E, MSH, 0xCA-MSH}
#define IPO_MODE2_PLAY		{0x04, 0x02, 0x00, 0x00, 0x01, 0xf9}
#define IPO_MODE2_PAUSE		{0x04, 0x02, 0x00, 0x00, 0x02, 0xf8}

volatile u8 ipo_rxsize = 0;
volatile u8 ipo_rxindex = 0;
volatile u8 ipo_rxdata[IPO_MAX_RX_SIZE];

volatile u8 ipo_txsize = 0;
volatile u8 ipo_txindex = 0;
volatile u8 ipo_txdata[IPO_MAX_TX_SIZE] = {
	0xff, 0x55, 0x03, 0x00, 0x01, 0x02, 0xfa, 0x00, 0x00, 0x00, 0x00, 0x00
};

// Function prototype
static void ipo_send( const u8 msg[] );

/*
 * Initialization function
 */
void ipo_init( void )
{
	// Set inputs and outputs according to manual
	set_bit( trisc,7 );		// RX
	set_bit( trisc,6 );		// TX

	// Clear flags
	ipo_flags = 0;

	// Enable USART interface
	rcsta = 0b10010000;

	// BRGH high baud rate selection
	txsta = 0b00100100;

	// Baud rate
	spbrg = BAUD38K4;

	// Init packet header
	ipo_txdata[0] = 0xff;
	ipo_txdata[1] = 0x55;

	// Clear these variables
	ipo_rxindex = 0;
	ipo_rxsize = IPO_MAX_RX_SIZE-1;
	ipo_txindex = 0;
	ipo_txsize = 0;

	// Initialize timer 1
	RELOAD_TIMER1;
	t1con = 0b00110001;
	clear_bit( pir1,TMR1IF );
	set_bit( pie1,TMR1IE );

	// Enable RX interrupts
	clear_bit( pir1,RCIF );
	set_bit( pie1,RCIE );
}

/*
 * Send ipo command
 */
void ipo_command( const u8 cmd, const u8 parm )
{
	// Wait until previous command has finished!
	while( test_bit(ipo_flags,f_ipo_tx) ) { };

	switch( cmd )
	{
	case IPO_PLAYLIST:
		{
			u8 list = (parm == 6) ? 0 : parm;
			const u8 msg[] = IPO_LIST( list );
			ipo_send( msg );
			set_bit( ipo_flags,f_ipo_playlist );
		}
		break;

	case IPO_EXECUTE:
		{
			const u8 msg[] = IPO_EXEC;
			ipo_send( msg );
		}
		break;

	case IPO_MODE:
		{
			const u8 msg[] = IPO_INIT( parm );
			ipo_send( msg );
		}
		break;

	case IPO_PLAY_MODE2:
		{
			const u8 msg[] = IPO_MODE2_PLAY;
			ipo_send( msg );
		}
		break;

	case IPO_PAUSE_MODE2:
		{
			const u8 msg[] = IPO_MODE2_PAUSE;
			ipo_send( msg );
		}
		break;

	case IPO_STATUS:
		{
			const u8 msg[] = IPO_STAT;
			ipo_send( msg );
		}
		break;

	case IPO_SHUFFLE:
		{
			const u8 msg[] = IPO_SHUF( parm );
			ipo_send( msg );
		}
		break;

	default:
		{
			const u8 msg[] = IPO_COMMAND( cmd );
			ipo_send( msg );
		}
		break;
	}
}

/*
 * Add item to queue
 */
void ipo_add_queue( const u8 cmd, const u8 parm )
{
	// Prevent the write pointer overwriting unprocessed items
	if( ((ipo_queue_wr+1) & (QUEUE_DEPTH-1)) == ipo_queue_rd )
		return;

	// Add command to queue
	ipo_queue[ipo_queue_wr].cmd = cmd;
	ipo_queue[ipo_queue_wr].parm = parm;

	// Update write pointer
	if( ++ipo_queue_wr >= QUEUE_DEPTH )
		ipo_queue_wr = 0;
}

/*
 * Process next item in queue
 */
void ipo_process_queue( void )
{
	// Check whether we have an item in the queue
	if( ipo_queue_rd != ipo_queue_wr )
	{
		const u8 cmd = ipo_queue[ipo_queue_rd].cmd;
		const u8 parm = ipo_queue[ipo_queue_rd].parm;
		ipo_command( cmd, parm );

		// Update read pointer
		if( ++ipo_queue_rd >= QUEUE_DEPTH )
			ipo_queue_rd = 0;
	}
}

/* 
 * Verify checksum of ipod response
 */
u8 ipo_checksum_ok( void )
{
	u8 length = ipo_rxdata[c_len];	// length
	u8 checksum = 0;				// length including checksum!
	u8 i = 0;

	// Calculate checksum by adding all relevant numbers
	while( i < length+2 )
	{
		checksum += ipo_rxdata[2+i];
		++i;
	}

	// Checksum should be multiple of 0x100 (thus 0x00)
	if( checksum != 0 )
		return 0;

	// Return response length (as encoded in the command)
	return length;
}

/*
 * Parse ipod response
 */
void ipo_parse( void )
{
	u8 length;

	// Check response header
	if(   ipo_rxdata[c_hdr1] != 0xff
	   || ipo_rxdata[c_hdr2] != 0x55 )
	{
		return;
	}

	// Check checksum
	if( (length = ipo_checksum_ok()) == 0 )
		return;

	// Switch on second command byte, first is 0x00
	switch( ipo_rxdata[c_cmd2] )
	{
	case 0x1D:
		/* Time and status info */
		if( length == 0x0C )
		{
			ipo_status = ipo_rxdata[0x0E];
		}
		break;
	}
}

/*
 * Start the transmission of the ipod command
 */
static void ipo_send( const u8 msg[] )
{
	// Copy entire message into tx buffer, calculate checksum
	u8 i = 0;
	u8 checksum = 0;
	u8 length = 2 + msg[0];
	while( i < length )
	{
		ipo_txdata[2+i] = msg[i];
		++i;
	}

	// Setup all variables and start transmission
	ipo_txindex = 1;
	ipo_txsize = 4 + ipo_txdata[2];

	// Send first byte :)
	set_bit( ipo_flags,f_ipo_tx );
	set_bit( txsta,TXEN );
	txreg = ipo_txdata[0];
	set_bit( pie1,TXIE );
}

#endif /* ENABLE_IPOD */
