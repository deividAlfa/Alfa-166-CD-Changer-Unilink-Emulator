/*
** $Id$
**
**    Copyright (C) 2006 Sander Huijsen 
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    any later version.
**
**    This program is distributed in the hope that it will be useful,
**    but WITHOUT ANY WARRANTY; without even the implied warranty of
**    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**    GNU General Public License for more details.
**
**    You should have received a copy of the GNU General Public License
**    along with this program; if not, write to the Free Software
**    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include <system.h>
#include "led.h"

volatile u8 led_state = Off;

// Turn on/off led, or toggle its state
void led_set( const u8 state )
{
	// Toggle current led state
	if( state == Toggle )
	    led_state ^= 0x1;
	else
		led_state = state;

	// Turn led on or off
	if( led_state == On )
		clear_bit( LED_PORT,0 );
	else
		set_bit( LED_PORT,0 );
}

// Turn on/off led, or toggle its state - used in interrupts
void led_set_int( const u8 state )
{
	// Toggle current led state
	if( state == Toggle )
	    led_state ^= 0x1;
	else
		led_state = state;

	// Turn led on or off
	if( led_state == On )
		clear_bit( LED_PORT,0 );
	else
		set_bit( LED_PORT,0 );
}
