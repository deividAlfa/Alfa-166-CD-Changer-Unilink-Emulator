/*
** $Id$
**
**    Copyright (C) 2006 Sander Huijsen 
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    any later version.
**
**    This program is distributed in the hope that it will be useful,
**    but WITHOUT ANY WARRANTY; without even the implied warranty of
**    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**    GNU General Public License for more details.
**
**    You should have received a copy of the GNU General Public License
**    along with this program; if not, write to the Free Software
**    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef UNILINK_H
#define UNILINK_H

#include "types.h"
#include "version.h"
#include "led.h"

enum e_flags
{
	f_uni_checksum_ok = 0,	// Unilink packet is valid
	f_uni_spi_tx,			// SPI is in Tx mode
	f_uni_rx_compl,			// Unilink packet is complete
	f_uni_tx_log,			// Unilink packet is transmitted, used in logging routine
	f_uni_timepoll_req,		// indicates a requested (time) poll
	f_uni_init_phase,		// timer 1 overflow occured
	f_uni_cd_mode,			// flag indicating we're in cd mode
	f_uni_bus_off			// bus is turned off
};

enum e_commands
{
	c_uni_magazine = 0,		// magazine info is requested
	c_uni_disc,				// disc total time is requested
	c_uni_curpos,			// time info update
	c_uni_change,			// disc change
	c_uni_unknown			// unknown???
};

// Status values
enum e_status
{
	e_uni_playing  = 0x00,
	e_uni_changed  = 0x20,
	e_uni_changing = 0x40,
	e_uni_idle     = 0x80
};

// Just a bunch of Unilink numbers
#define C_UNI_BROADCAST	         	0x18		// broadcast ID
#define	C_UNI_MASTER	         	0x10		// masters ID
#define	C_UNI_DISPLAY	         	0x70		// display ID
#define C_UNI_DSP					0x90		// DSP ID
#define	C_UNI_CD		         	0x30		// my group ID for CDC

#define	C_UNI_CMD_BUSRQ			 	0x01		// cmd 1 bus request
#define	C_UNI_CMD_BUSRQ_RESET	 	0x00		// cmd 2 re-initialize bus
#define	C_UNI_CMD_BUSRQ_ANYONE	 	0x02		// cmd 2 anyone
#define	C_UNI_CMD_BUSRQ_ANYONES	 	0x03		// cmd 2 anyone special
#define	C_UNI_CMD_BUSRQ_TPOLLE	 	0x11		// cmd 2 time poll end
#define	C_UNI_CMD_BUSRQ_TPOLL	 	0x12		// cmd 2 time poll
#define	C_UNI_CMD_BUSRQ_POLL	 	0x13		// cmd 2 request time poll
#define	C_UNI_CMD_BUSRQ_POLLWHO	 	0x15		// cmd 2 who want to talk

#define	C_UNI_CMD_CONFIG		 	0x02		// cmd 1 config, for appoint
#define C_UNI_CMD_KEYOFF			0x08		// cmd 1 key off (cancel)
#define	C_UNI_CMD_PLAY			 	0x20		// cmd 1 play
#define C_UNI_CMD_SWITCH			0x21		// cmd 1 TA message ?
#define C_UNI_CMD_CHANGEDOWN		0x22		// cmd 1 Change Down
#define C_UNI_CMD_CHANGEUP			0x23		// cmd 1 Change Up
#define C_UNI_CMD_FFWD				0x24		// cmd 1 Fast Forward
#define C_UNI_CMD_FREV				0x25		// cmd 1 Fast Reverse
#define	C_UNI_CMD_NEXTTRACK		 	0x26		// cmd 1 next track
#define	C_UNI_CMD_PREVTRACK		 	0x27		// cmd 1 prev track
#define C_UNI_CMD_NEXTCD			0x28		// cmd 1 next CD
#define C_UNI_CMD_PREVCD			0x29		// cmd 1 prev CD
#define C_UNI_CMD_REPEAT			0x34		// cmd 1 Repeat Mode
#define C_UNI_CMD_SHUFFLE			0x35		// cmd 1 Shuffle Mode
#define	C_UNI_CMD_DISPKEY		 	0x80		// cmd 1 display key, switch through display modes
#define	C_UNI_CMD_TEXTRQ		 	0x84		// cmd 1 text request
#define	C_UNI_CMD_POWEROFF1		 	0x87		// cmd 1 power off
#define C_UNI_CMD_MAGAZINE			0x95		// cmd 1 Magazine Info
#define C_UNI_CMD_DISC				0x97		// cmd 1 Disc Info
#define C_UNI_CMD_SELECTCD			0xB0		// cmd 1 select CD
#define	C_UNI_CMD_SELECT		 	0xF0		// cmd 1 select source

// Specific device ID for Becker 2660AR (Alfa 166)
#define CD_DEVICE_MSG1	{0x10, uni_ownaddr, 0x8C, 0x11, 0x14, 0xA8, 0x17, 0x60}
#define CD_DEVICE_MSG2	{0x10, uni_ownaddr, 0x8C, 0x11, 0x15, 0xA8, 0x17, 0x60}

// UNILINK Commands
#define STATUS_MSG		{C_UNI_MASTER, uni_ownaddr, 0x00, uni_status}
#define YOU_MISSED_ME	{C_UNI_MASTER, uni_ownaddr, 0x04, 0x00}
#define TIME_POLL		{C_UNI_DISPLAY, uni_ownaddr, 0x90, 0x00, uni_track, uni_time1, uni_time0, (uni_disc<<4)|0x0A}
#define MSG_UNKNOWN		{C_UNI_DISPLAY, uni_ownaddr, 0x94, 0x20, 0x00, 0x00, 0x00, 0x00}
#define MAG_MSG			{uni_mydest, uni_ownaddr, 0x95, 0x00, 0x00, 0x00, 0x00, uni_disc}
#define DISC_MSG		{C_UNI_MASTER, uni_ownaddr, 0x97, 0x01, uni_discinfo[uni_disc], 0x50, 0x22, uni_disc<<4}
#define DISC_CHANGE		{C_UNI_DSP, uni_ownaddr, 0x9C, 0x00, 0x00, 0x00, 0x00, (uni_disc<<4)|0x08}

// Byte in packet array locations
#define destaddr     0              // destination address
#define srcaddr      1              // source address
#define cmd1         2              // command 1
#define cmd2         3              // command 2
#define parity1      4              // parity 1
#define data         5              // start of data
#define d1			 5				// data byte 1 D1
#define d2			 6				// data byte 2 D2
#define d3			 7				// data byte 3 D3
#define d4			 8				// data byte 4 D4
#define d5			 9				// data byte 5 D2_1
#define d6			10				// data byte 6 D2_2
#define d7			11				// data byte 7 D2_3
#define d8			12				// data byte 8 D2_4
#define d9			13				// data byte 9 D2_5

/* EXPORTED VARIABLES *********************************************************/

extern u8 uni_bytecount_rx;
extern u8 uni_bytecount_tx;
extern u8 uni_command;
extern u8 uni_flags;
extern u8 uni_appoint_count;

extern u8 uni_ownaddr;            	// holds the actual ID
extern u8 uni_groupid;				// holds current group ID
extern u8 uni_rxsize;            	// receive packet size in bytes
extern u8 uni_txsize;            	// transmit packet size in bytes

extern enum e_status uni_status;    // initial interface status (Idle)
extern u8 uni_rxdata[16];           // holds the received packet
extern u8 uni_txdata[16];           // holds the transmit packet

extern u8 uni_discinfo[6];			// # of track per discs

extern u8 uni_time0;
extern u8 uni_time1;
extern u8 uni_disc;
extern u8 uni_track;

extern u8 uni_mydest;				// first destination of Magazine-Info

/* FUNCTION PROTOTYPES ********************************************************/

void uni_parse( void );
void uni_tx( const u8 *msg );

// Inline initialization function
inline void uni_init( void )
{
	// Make sure adcon1 has correct value - all digital lines
	adcon1 = 0b00001111;

	// Set inputs and outputs according to manual
	porta = 0b00100000;
	set_bit( trisc,3 );		// SCK
	set_bit( trisc,5 );		// SDO
	set_bit( trisa,5 );		// nSS

	// Clear SSPEN before changing SSP registers
	clear_bit( sspcon,SSPEN );

	// Enable SPI, clock idle is HIGH, slave mode
	sspcon = 0b00010101;

	// Data on falling edge
	sspstat = 0b00000000;

	// Wait for clock pin to have correct Idle state (== high)
	while( !test_bit(portc,3) )
	{
		/* Do nothing */
	}

	// Set SSPEN to enable SSP module
	set_bit( sspcon,SSPEN );

	// Enable SSP interrupts
	clear_bit( pir1,SSPIF );
	set_bit( pie1,SSPIE );

	// Turn off led
//	led_set( Off );
}

/*
 * Unilink packet interrupt handler
 */
inline void uni_packet_interrupt( void )
{
	// SSP interrupt
	if( test_bit(pie1,SSPIE) && test_bit(pir1,SSPIF) )
	{
		if( !test_bit(uni_flags,f_uni_spi_tx) )
		{
			// SPI RX
			uni_rxdata[uni_bytecount_rx] = sspbuf;
			if(   uni_bytecount_rx == 0
			   && uni_rxdata[0] == 0 )
			{
				return;
			}

			// Turn on LED after we've started receiving something
//			led_set_int( On );

			// Determine packet length
			if( uni_rxdata[2] >= 0xC0 )
				uni_rxsize = 16;
			else if( uni_rxdata[2] >= 0x80 )
				uni_rxsize = 11;
			else
				uni_rxsize = 6;

			// Check whether we've received a complete packet
			++uni_bytecount_rx;
			if( uni_bytecount_rx >= uni_rxsize )
			{
				// We're done receiving, we got a complete packet - reset WDT
//				led_set_int( Off );
				clear_wdt();
				uni_bytecount_rx = 0;
				set_bit( uni_flags,f_uni_rx_compl );
			}
		}
		else
		{
			// More bytes to send? 
			if( uni_bytecount_tx <= uni_txsize )
			{
				// Yes, send it.
				sspbuf = uni_txdata[uni_bytecount_tx];
				++uni_bytecount_tx;
			}
			else
			{
				// No, send delimiting 0.
				sspbuf = 0x00;
				clear_bit( uni_flags,f_uni_spi_tx );
				set_bit( uni_flags,f_uni_tx_log );

				// Configure SDO tri-state
				set_bit( trisc,5 );
			}
		} 

		// Clear interrupt flag
		clear_bit( pir1,SSPIF );
	}
}

#endif /* UNILINK_H */
