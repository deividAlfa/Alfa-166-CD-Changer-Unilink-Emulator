/*
** $Id$
**
**    Copyright (C) 2006 Sander Huijsen 
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    any later version.
**
**    This program is distributed in the hope that it will be useful,
**    but WITHOUT ANY WARRANTY; without even the implied warranty of
**    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**    GNU General Public License for more details.
**
**    You should have received a copy of the GNU General Public License
**    along with this program; if not, write to the Free Software
**    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef VERSION_H
#define VERSION_H

/*
 * Select version 2 for iPod support
 */
#define VERSION2

// This must overrule ipod support!
//#define BUS_LOGGING

// For some Sony HU functionality
#define COMPAT_SONY

#ifdef VERSION2
// Version 2 including iPod support
#define VERSION_MAJOR	0x02
#define VERSION_MINOR	0x04

#ifndef BUS_LOGGING
#define ENABLE_IPOD
#endif

#else
// Version 1 excluding iPod support
#define VERSION_MAJOR	0x01
#define VERSION_MINOR	0x56
#endif /* VERSION2 */

#endif /* VERSION_H */
