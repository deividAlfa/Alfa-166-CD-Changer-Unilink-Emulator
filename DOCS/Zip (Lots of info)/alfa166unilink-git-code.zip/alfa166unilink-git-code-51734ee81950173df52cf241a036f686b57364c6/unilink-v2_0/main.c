/*
** $Id$
**
**    Copyright (C) 2006 Sander Huijsen 
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    any later version.
**
**    This program is distributed in the hope that it will be useful,
**    but WITHOUT ANY WARRANTY; without even the implied warranty of
**    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**    GNU General Public License for more details.
**
**    You should have received a copy of the GNU General Public License
**    along with this program; if not, write to the Free Software
**    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include <system.h>
#include "version.h"
#include "types.h"
#include "general.h"
#include "ipod.h"
#include "unilink.h"
#include "led.h"
#include "log.h"

#pragma CLOCK_FREQ 16000000

#ifdef _PIC16F77
/*
 * High-speed oscillator
 * No watchdog
 * No Brown-out Reset
 * Power-up timer
 */
#pragma DATA _CONFIG, _HS_OSC & _WDT_OFF & _BODEN_OFF
#endif /* _PIC16F77 */

#if defined(_PIC16F767) || defined(_PIC16F737)
/*
 * High-speed oscillator
 * Watchdog
 * Power-up timer
 */
#pragma DATA _CONFIG1, _HS_OSC & _WDT_OFF & _MCLR_ON & _BOREN_0
#pragma DATA _CONFIG2, _BORSEN_0
#endif /* _PIC16F767 */

/*
 * Interrupt routine
 */
void interrupt( void )
{
	// Ipod TX interrupt
	ipo_tx_interrupt();

	// Ipod RX interrupt
	ipo_rx_interrupt();

	// 10ms timer
	ipo_timer1_interrupt();

	// Unilink packet handling
	uni_packet_interrupt();
}

/*
 * Main function
 */
void main( void )
{
	// Set output for controlling LED
	clear_bit( LED_TRIS,0 );

	// Turn on peripheral interrupts
	set_bit( intcon,PEIE );

	// Enable global interrupts
	ei();

	// Initialize timer0, prescale with 256
	// Timer 0 runs at 16MHz / 4 / 256 = 15,625 kHz
	option_reg = 0b00000111;

	// Initialize unilink interface
	uni_init();

	// Initialize USART interface for ipod control
	ipo_init();

	// Initialize USART interface for bus logging
	log_init();

	// Put ipod in AiR mode
	ipo_add_queue( IPO_MODE, IPO_MODE_AIR );
	ipo_process_queue();

	// Only initialize after proper power up
	if( restart_cause() == NORMAL_POWER_UP )
	{
		// Set /POR bit in PCON register
		set_bit( pcon,NOT_POR );

		// Set init phase bit
		set_bit( uni_flags,f_uni_init_phase );

		// Initialize some variables
		uni_time0 = 5;
		uni_time1 = 7;
		uni_disc = 1;
		uni_track = 1;
		uni_mydest = C_UNI_DISPLAY+0x7;
	}

warmboot:
	led_set( Off );
	uni_ownaddr = C_UNI_CD;
	uni_groupid = C_UNI_CD;
	uni_status = e_uni_idle;
	uni_appoint_count = 1;

	// Setup Watchdog timer
	wdtcon = WDT_2097MS;

	// Forever loop
	forever
	{
		// Check for a valid unilink packet
		if( test_bit(uni_flags,f_uni_rx_compl) )
		{
			clear_bit( uni_flags,f_uni_rx_compl );

			// Parse newly received packet
			uni_parse();

			// Log received packet
			log_bus();
		}

		// Check whether we need to log a TX'd packet
		if( test_bit(uni_flags,f_uni_tx_log) )
		{
			// Log transmitted packet
			log_bus();
		}

		// Check for execute command
		if( test_bit(ipo_flags,f_ipo_execute) )
		{
			clear_bit( ipo_flags,f_ipo_execute );

			// Send execute, update flag
			ipo_add_queue( IPO_EXECUTE, 0 );
		}

		// Is it time to update our status?
		if( test_bit(ipo_flags,f_ipo_status) )
		{
			clear_bit( ipo_flags,f_ipo_status );

			// Update our status
			ipo_add_queue( IPO_STATUS, 0 );
		}

		// Did we receive a response from the ipod?
		if( test_bit(ipo_flags,f_ipo_rx_compl) )
		{
			clear_bit( ipo_flags,f_ipo_rx_compl );

			// Handle ipod response
			ipo_parse();
		}

		// Check for 10ms timeout
		if( test_bit(ipo_flags,f_ipo_timeout) )
		{
			clear_bit( ipo_flags,f_ipo_timeout );

			// Process ipod message queue
			ipo_process_queue();
		}

		if( test_bit(porta,5) )
		{
			led_set( Off );
			delay_ms( 500 );
			if( test_bit(porta,5) )
			{
				if( ipo_status == IPO_ST_PLAYING )
				{
					ipo_add_queue( IPO_PLAY,0 );
					ipo_status = IPO_ST_PAUSED;
					delay_ms( 2 );
				}

				led_set( On );
				do
				{
					clear_wdt();
					sleep();
					nop();
				}
				while( test_bit(porta,5) );

//				led_set( On );
				goto warmboot;
			}
		}
	}
}
