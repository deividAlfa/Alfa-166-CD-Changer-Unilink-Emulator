/*
** $Id$
**
**    Copyright (C) 2006 Sander Huijsen 
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    any later version.
**
**    This program is distributed in the hope that it will be useful,
**    but WITHOUT ANY WARRANTY; without even the implied warranty of
**    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**    GNU General Public License for more details.
**
**    You should have received a copy of the GNU General Public License
**    along with this program; if not, write to the Free Software
**    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef LED_H
#define LED_H

#include <system.h>
#include "general.h"
#include "types.h"

#ifdef _PIC16F77
#define LED_PORT	porta
#define LED_TRIS	trisa
#else
#define LED_PORT	portc
#define LED_TRIS	trisc
#endif /* _PIC16F77 */

// Led Status
enum e_led_state
{
	Off    = 0,
	On     = 1,
	Toggle = 2
};

// Turn LED on/off or toggle
void led_set( const u8 state );
void led_set_int( const u8 state );

#endif /* LED_H */
