#ifndef LOG_H
#define LOG_H

#include "general.h"
#include "version.h"

#ifdef BUS_LOGGING

void log_init( void );
void log_bus( void );

#else /* BUS_LOGGING */

inline void log_init( void ) { };
inline void log_bus( void ) { };

#endif /* BUS_LOGGING */

#endif /* LOG_H */
