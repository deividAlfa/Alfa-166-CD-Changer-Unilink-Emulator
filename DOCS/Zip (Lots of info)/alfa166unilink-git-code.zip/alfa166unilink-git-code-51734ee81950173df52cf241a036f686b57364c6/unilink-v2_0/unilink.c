/*
** $Id$
**
**    Copyright (C) 2006 Sander Huijsen 
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    any later version.
**
**    This program is distributed in the hope that it will be useful,
**    but WITHOUT ANY WARRANTY; without even the implied warranty of
**    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**    GNU General Public License for more details.
**
**    You should have received a copy of the GNU General Public License
**    along with this program; if not, write to the Free Software
**    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include <system.h>
#include "unilink.h"
#include "general.h"
#include "version.h"
#include "ipod.h"
#include "led.h"

/* LOCAL FUNCTION PROTOTYPES **************************************************/

static u8 bcd_incr( const u8 num );
static void send_command( void );
static void slavebreak( void );
static u8 checksum_ok( void );

/* EXPORTED VARIABLES *********************************************************/

volatile u8 uni_bytecount_rx;
volatile u8 uni_bytecount_tx;
volatile u8 uni_command = 0;
volatile u8 uni_flags = 0;
volatile u8 uni_appoint_count = 0;

volatile u8 uni_ownaddr = C_UNI_CD;				// holds the actual ID
volatile u8 uni_groupid = C_UNI_CD;				// holds current group ID
volatile u8 uni_rxsize =  0;            		// receive packet size in bytes
volatile u8 uni_txsize =  0;            		// transmit packet size in bytes

volatile enum e_status uni_status = e_uni_idle;		// initial interface status (Idle)
volatile u8 uni_rxdata[16];             		// holds the received packet
volatile u8 uni_txdata[16];             		// holds the transmit packet

// This array is used from 1..6 (0 not used)
volatile u8 uni_discinfo[] = {
	0x00, 0x10, 0x20, 0x30, 0x40, 0x50, 0x60
};

// Needed to detect disc and track change
volatile u8 uni_time0 = 5;
volatile u8 uni_time1 = 7;
volatile u8 uni_disc = 1;
volatile u8 uni_track = 1;

volatile u8 uni_mydest = C_UNI_DISPLAY+0x7;	// first destination of Magazine-Info

#ifdef COMPAT_SONY
#define MAX_PING_COUNT	6

volatile u8 uni_ping_count = 0;
#endif /* COMPAT_SONY */

/*
 * Parse unilink packet
 */
void uni_parse( void )
{
	// First check checksum of new packet
	if( !checksum_ok() )
		return;

	switch( uni_rxdata[cmd1] )
	{
	/* 0x01 Bus Request */
    case C_UNI_CMD_BUSRQ:
        switch( uni_rxdata[cmd2] )
        {
		/* 0x00 Re-initialize bus */
        case C_UNI_CMD_BUSRQ_RESET:
			uni_appoint_count = 1;
			uni_ownaddr = C_UNI_CD;
			uni_groupid = C_UNI_CD;
			uni_ping_count = 0;
//			led_set( Off );
            break;

       	/* 0x02 Anyone? */
        case C_UNI_CMD_BUSRQ_ANYONE:
			if( uni_appoint_count > 0 )
			{
				--uni_appoint_count;

				const u8 msg[8] = CD_DEVICE_MSG1;
				uni_tx( msg );
			}
            break;

		/* 0x11 Ping-End */
		case C_UNI_CMD_BUSRQ_TPOLLE:
#ifdef COMPAT_SONY
			if( ++uni_ping_count > MAX_PING_COUNT )
			{
				// We've missed too many pings - force bus reset
				const u8 msg[] = YOU_MISSED_ME;
				uni_tx( msg );
			}
#endif /* COMPAT_SONY */
			break;

		/* 0x12 Ping */
		case C_UNI_CMD_BUSRQ_TPOLL:
			if( uni_rxdata[destaddr] == uni_ownaddr )
			{
				unsigned char msg[4] = STATUS_MSG;
				uni_tx( msg );
	
				if( uni_status == e_uni_changed )
					uni_status = e_uni_playing;
	
				if( uni_status == e_uni_playing )
				{
					// Update time
					uni_time0 = bcd_incr( uni_time0 );
					if( uni_time0 == 0x60 )
					{
						uni_time0 = 0x00;
						uni_time1 = bcd_incr( uni_time1 );
					}
					slavebreak();
					uni_command = c_uni_curpos;
				}

#ifdef COMPAT_SONY
				// Update ping count
				uni_ping_count = 0;
#endif /* COMPAT_SONY */
	
				// Schedule new status update for ipod
				ipo_add_queue( IPO_STATUS, 0 );
			}
			break;

		/* 0x13 Slave poll */
		case C_UNI_CMD_BUSRQ_POLL:
			if( uni_rxdata[destaddr] == uni_ownaddr )
			{
				send_command();
			}
			break;
		}
		break;

	/* 0x02 Appoint response */
	case C_UNI_CMD_BUSRQ_ANYONE:
		{
			// Appoint for us?
			if( (uni_rxdata[destaddr]&0xF0) != uni_groupid )
				return;

			// Are we expecting this?
			if( uni_appoint_count != 0 )
				return;

			// We now have our own id
			uni_ownaddr = uni_rxdata[destaddr];
			const u8 msg[] = CD_DEVICE_MSG1;
			uni_tx( msg );
//			led_set( On );
		}
		break;

	/* 0x20 Play */
	case C_UNI_CMD_PLAY:
		break;

	/* 0x87 Power Event */
	case C_UNI_CMD_POWEROFF1:
		switch( uni_rxdata[cmd2] )
		{
		case 0x89:
			if( test_bit(uni_flags,f_uni_init_phase) )
			{
				// Init Phase
				uni_status = e_uni_changing;
				slavebreak();
				uni_command = c_uni_magazine;
			}
			else
			{
				set_bit( uni_flags,f_uni_cd_mode );
				uni_status = e_uni_playing;
				slavebreak();
				uni_command = c_uni_curpos;
			}

			// Check ipod status before changing it
			if( ipo_status != IPO_ST_PLAYING )
			{
				ipo_add_queue( IPO_PLAY, 0 );
				ipo_status = IPO_ST_PLAYING;
			}
			break;

		case 0x00:
			clear_bit( uni_flags,f_uni_cd_mode );
			uni_status = e_uni_idle;
			if( ipo_status == IPO_ST_PLAYING )
			{
				ipo_add_queue( IPO_PLAY, 0 );
				ipo_status = IPO_ST_PAUSED;
			}
			break;
		}
		break;

#ifdef COMPAT_SONY
	/* 0xF0 Source select */
	case C_UNI_CMD_SELECT:
		if( uni_rxdata[cmd2] != uni_ownaddr )
		{
			// Different source
			clear_bit( uni_flags,f_uni_cd_mode );
			uni_status = e_uni_idle;
			if( ipo_status == IPO_ST_PLAYING )
			{
				ipo_add_queue( IPO_PLAY, 0 );
				ipo_status = IPO_ST_PAUSED;
			}
		}
		else
		{
			// I'm the new source
			set_bit( uni_flags,f_uni_cd_mode );
			uni_status = e_uni_playing;
			if( ipo_status != IPO_ST_PLAYING )
			{
				ipo_add_queue( IPO_PLAY, 0 );
				ipo_status = IPO_ST_PLAYING;
			}
		}
		break;
#endif /* COMPAT_SONY */
	}

	// If we're not selected, we're done here
	if( !test_bit(uni_flags,f_uni_cd_mode) )
		return;

	switch( uni_rxdata[cmd1] )
	{
	/* 0x08 Release */
	case C_UNI_CMD_KEYOFF:
		if( test_bit(ipo_flags,f_ipo_hold) )
		{
			clear_bit( ipo_flags,f_ipo_hold );
			ipo_add_queue( IPO_KEYOFF, 0 );
		}
		break;

	/* 0x24, command is ended by KEYOFF (0x08) */
	case C_UNI_CMD_FFWD:
		set_bit( ipo_flags,f_ipo_hold );
		ipo_add_queue( IPO_FFWD, 0 );
		break;

	/* 0x25, command is ended by KEYOFF (0x08) */
	case C_UNI_CMD_FREV:
		set_bit( ipo_flags,f_ipo_hold );
		ipo_add_queue( IPO_RWD, 0 );
		break;

#ifdef COMPAT_SONY
	/* 0x26 */
	case C_UNI_CMD_NEXTTRACK:
		ipo_add_queue( IPO_NEXT, 0 );
		break;

	/* 0x27 */
	case C_UNI_CMD_PREVTRACK:
		ipo_add_queue( IPO_PREV, 0 );
		break;

	/* 0x28 */
	case C_UNI_CMD_NEXTCD:
		if( ++uni_disc > 6 )
			uni_disc = 1;

		ipo_add_queue( IPO_PLAYLIST, uni_disc );
		break;

	/* 0x29 */
	case C_UNI_CMD_PREVCD:
		if( --uni_disc == 0 )
			uni_disc = 6;

		ipo_add_queue( IPO_PLAYLIST, uni_disc );
		break;
#endif /* COMPAT_SONY */

	/* 0x84 */
	case C_UNI_CMD_TEXTRQ:
		switch( uni_rxdata[cmd2] )
		{
		/* 0x95 Magazine-Info */
		case C_UNI_CMD_MAGAZINE:
			slavebreak();
			uni_command = c_uni_magazine;
			break;

		/* 0x97 Disc-Info */
		case C_UNI_CMD_DISC:
			slavebreak();
			uni_command = c_uni_disc;
			break;
		}
        break;

#define NEXT_TRACK	( 1 + (uni_track % uni_discinfo[uni_disc]) )

	/* 0xB0 Select CD */
	case C_UNI_CMD_SELECTCD:
		{
			const u8 newtrack = uni_rxdata[d1];
			const u8 newdisc = uni_rxdata[cmd2] & 0x0F;

			if( newtrack != 0 )
			{
				uni_track = newtrack;
				slavebreak();
				uni_command = c_uni_curpos;

				// Update
				if( newtrack == NEXT_TRACK )
					ipo_add_queue( IPO_NEXT, 0 );
				else
					ipo_add_queue( IPO_PREV, 0 );
			}
			else
			{
				uni_status = e_uni_changed;
				uni_track = 1;
				uni_disc = newdisc;
				slavebreak();
				uni_command = c_uni_change;

				// Disc change
				ipo_add_queue( IPO_PLAYLIST, newdisc );
			}
			uni_time0 = 0;	// seconds
			uni_time1 = 0;	// minutes
		}
		break;
    }
}

/*
 * Send unilink message
 */
void uni_tx( const u8 *msg )
{
	unsigned char loc_checksum = 0;     // local checksum

	// Determine packet length
	if( msg[2] >= 0xC0 ) 
		uni_txsize = 14;
	else if( msg[2] >= 0x80 )
		uni_txsize = 9;
	else 
		uni_txsize = 4;

	// RAD
	loc_checksum += msg[destaddr];
	uni_txdata[destaddr] = msg[destaddr];

	// TAD
	loc_checksum += msg[srcaddr];
	uni_txdata[srcaddr] = msg[srcaddr];

	// CMD1
	loc_checksum += msg[cmd1];
	uni_txdata[cmd1] = msg[cmd1];

	// CMD2
	loc_checksum += msg[cmd2];
	uni_txdata[cmd2] = msg[cmd2];

	// Parity1
	uni_txdata[parity1] = loc_checksum;

	// Copy rest of the message
	if( uni_txsize > 4 )
	{
		unsigned char loc_index = parity1;
		do
		{
			uni_txdata[loc_index+1] = msg[loc_index];
			loc_checksum += msg[loc_index];
			++loc_index;
		}
		while( loc_index < uni_txsize-1 );

		// Store parity2
		uni_txdata[loc_index+1] = loc_checksum;
	}

	// Configure SDO as output
	clear_bit( trisc,5 );
	set_bit( uni_flags,f_uni_spi_tx );
	uni_bytecount_tx = 1;                           // set bytecount to 1 because one byte is send direct
	sspbuf = uni_txdata[destaddr];		            // send 1st byte to SPI, rest via SPI interrupt routine
}

/*
 * Calculate checksum and set flag accordingly.
 * Return: 	0 if checksum fails
 * 		 	1 if checksum is ok
 */
u8 checksum_ok( void )
{
	u8 checksum = 0;
	u8 bytecount = 0;
	u8 rxsize = uni_rxsize - 2;	// skip parity and 0-byte

	// Last byte must be 0x00
	if( uni_rxdata[rxsize+1] != 0 )
		return 0;

	// Calculate checksum1
	for( ; bytecount < 4; ++bytecount )
		checksum += uni_rxdata[bytecount];

	// Checksum fails!
	if( checksum != uni_rxdata[parity1] )
		return 0;

	// Skip parity1 byte in calculation
	++bytecount;

	// This loop is effectively skipped in case of 6-byte short word
	for( ; bytecount < rxsize; ++bytecount )
		checksum += uni_rxdata[bytecount];

	// Checksum fails! rxsize == parity1 in case of 6-byte short word
	if( checksum != uni_rxdata[rxsize] )
		return 0;

	// If we make it here, checksum is ok!
	return 1;
}

/* 
 * Send command
 */
void send_command( void )
{
	// Did we expect a permission-to-talk?
	if( !test_bit(uni_flags,f_uni_timepoll_req) )
		return;

	// Clear timepoll bit
	clear_bit( uni_flags,f_uni_timepoll_req );

	switch( uni_command )
	{
	case c_uni_magazine:
		{
			// Magazine Info
			unsigned char msg[] = MAG_MSG;
			uni_tx( msg );
			uni_mydest = C_UNI_MASTER;
			if( test_bit(uni_flags,f_uni_init_phase) )
			{
				// Still in Init Phase
				uni_status = e_uni_changing;
				uni_command = c_uni_change;
				clear_bit( uni_flags,f_uni_init_phase );
				slavebreak();
			}
		}
		break;

	case c_uni_disc:
		{
			// Disc Info
			unsigned char msg[] = DISC_MSG;
			uni_tx( msg );
			if( uni_status == e_uni_playing )
			{
				/* We're playing, send current play position */
				slavebreak();
				uni_command = c_uni_curpos;
			}
		}
		break;

	case c_uni_curpos:
		{
			// Current playing position
			unsigned char msg[] = TIME_POLL;
			uni_tx( msg );
		}
		break;

	case c_uni_change:
		{
			// Disc change
			unsigned char msg[] = DISC_CHANGE;
			uni_tx( msg );
			if( uni_status == e_uni_changed )
			{
				slavebreak();
				uni_command = c_uni_unknown;
			}
			else
			{
				/* e.g., uni_status == e_changing */
				uni_status = e_uni_playing;
			}
		}
		break;

	case c_uni_unknown:
		{
			// Unknown???
			unsigned char msg[] = MSG_UNKNOWN;
			uni_tx( msg );
		}
		break;
	}
}

/*
 * Wait for idle time between two packets, then do slave break
 */
void slavebreak( void )
{
    /*
     * Wait for data line low for minimum of 7ms
     */
	clear_bit( intcon,T0IF );
    tmr0 = C_7MS;
	while( !test_bit(intcon,T0IF) )
    {
        if( !test_bit(portc,4) ) 
			tmr0 = C_7MS;
    }

	/*
     * Wait for data line high for 2ms
	 */
    clear_bit( intcon,T0IF );
    tmr0 = C_2MS;
    while( !test_bit(intcon,T0IF) )
    {
        if( test_bit(portc,4) )
			tmr0 = C_2MS;
    }

	/*
     * Force data line 3ms low
	 */
	clear_bit( intcon,T0IF );
    tmr0 = C_3MS;

    // Transistor pulls data line low
    set_bit( portc,5 );
    while( !test_bit(intcon,T0IF) )
    {
		/* do nothing */
    }

	// Free data line
	clear_bit( portc,5 );
    set_bit( uni_flags,f_uni_timepoll_req );
}

/*
 * Increment BCD number
 */
u8 bcd_incr( const u8 num ) 
{
	u8 a = num & 0x0F;
	u8 b = num & 0xF0;

	if( ++a > 9 )
	{
	   a = 0;
	   b += 0x10;
	}
	return( b | a );
}
