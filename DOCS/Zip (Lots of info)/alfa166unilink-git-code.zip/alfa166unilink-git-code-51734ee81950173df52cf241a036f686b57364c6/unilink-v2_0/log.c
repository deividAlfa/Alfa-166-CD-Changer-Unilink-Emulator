#include <system.h>
#include "log.h"
#include "types.h"
#include "unilink.h"

#ifdef BUS_LOGGING

static u8 bin2ascii( u8 ch );
static void log_putc( const u8 ch );

/*
 * Initialize logging on usart
 */
void log_init( void )
{
	// Set inputs and outputs according to manual
	set_bit( trisc,7 );		// RX
	set_bit( trisc,6 );		// TX

	// Enable USART interface
	rcsta = 0b10000000;

	// BRGH high baud rate selection
	txsta = 0b00100100;

	// Baud rate
	spbrg = BAUD38K4;

	// Init - debug purposes?
	log_putc( 0x55 );
}

/*
 * Perform actual logging
 */
void log_bus( void )
{
	u8 lcount = 0;	// byte counter
	u8 ltemp = 0;	// temp variable
	u8 *ldp;		// data buffer pointer

	if( test_bit(uni_flags,f_uni_tx_log) )
	{
		// Log a TX'd packet
		clear_bit( uni_flags,f_uni_tx_log );
		ldp = uni_txdata;
		lcount = uni_txsize + 1;
		log_putc( 0x0a );
		log_putc( 0x0d );
		log_putc( 0x23 );
	}
	else
	{
		// Log an RX'd packet
		ldp = uni_rxdata;
		lcount = uni_rxsize-1;
		log_putc( 0x0a );
		log_putc( 0x0d );
		log_putc( 0xab );
	}

	// Convert to ascii while dumping the packet
	while( lcount )
	{
		ltemp = *ldp++;
		log_putc( bin2ascii(ltemp>>4) );
		log_putc( bin2ascii(ltemp) );
		log_putc( ' ' );
		--lcount;
 	}
	log_putc( '0' );
	log_putc( '0' );
}

/*
 * Convert binary to ascii
 */
static u8 bin2ascii( u8 ch )
{
	ch &= 0x0f;
    if( ch < 10 )
		return ch + 48;
    else
        return ch + 55;
}

/*
 * Send single character
 */
static void log_putc( const u8 ch )
{
	while( !test_bit(txsta,TRMT) ) 
	{ 
		/* wait for usart to become available */
	}
	
	// Send character
	txreg = ch;
}

#endif /* BUS_LOGGING */
